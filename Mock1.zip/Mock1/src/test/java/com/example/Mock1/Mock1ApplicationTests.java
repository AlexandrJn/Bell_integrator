package com.example.Mock1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mock1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
