package com.example.Mock1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mock1Application {

	public static void main(String[] args) {
		SpringApplication.run(Mock1Application.class, args);}
	}
